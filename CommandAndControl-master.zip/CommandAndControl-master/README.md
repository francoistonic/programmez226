# CommandAndControl

This repo contains the code for a basic and simple Command & COPntrol service.
It hosts a socket server and wait for instructions. Then it executes the command via CreateProcess.

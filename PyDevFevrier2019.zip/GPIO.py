import time

BOARD = 1
OUT = 1
IN = 1
HIGH=1
LOW=0
PUD_DOWN=0

def setmode(arg):
  print (arg)
   
def setup(pin, state, initial=-1, pull_up_down=-1):
  print "setup:", pin, "with", state
   
def output(arg1, arg2):
  print "output: " ,arg1, "-" ,arg2 
   
def input(arg1):
  print " input: " ,arg1
  time.sleep(0.1)
  return (1)

def cleanup():
  print " cleanup "
   
def setwarnings(flag):
  print " setwarning:  " + flag